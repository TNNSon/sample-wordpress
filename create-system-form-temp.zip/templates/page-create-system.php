<?php
/* Template Name: Create System */

get_header();
?>
<div class="create-system-container">
    <form class="create-system-form" method="post" action="<?php echo esc_url(home_url('/wp-json/create-system/v1/submit')); ?>">
        <?php
        while (have_posts()) : the_post();
            the_content(); // Dynamically renders blocks (inputs + submit button)
        endwhile;
        ?>
    </form>
</div>
<!-- <script>
document.addEventListener('submit', (event) => {
    if (event.target.matches('.create-system-container')) {
        event.preventDefault();

        const formData = new FormData(event.target);
        const data = Object.fromEntries(formData.entries());

        fetch('/wp-json/create-system/v1/submit', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        })
            .then((response) => response.json())
            .then((result) => {
                if (result.success) {
                    alert('System created successfully!');
                    window.location.reload();
                } else {
                    alert('Error creating system.');
                }
            })
            .catch((error) => console.error('Error:', error));
    }
});

</script> -->

<?php
get_footer();
