document.addEventListener("submit", (event) => {
  if (event.target.matches(".create-system-container form")) {
    event.preventDefault();

    const formData = new FormData(event.target);
    const data = Object.fromEntries(formData.entries());

    fetch("/wp-json/create-system/v1/submit", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    })
      .then((response) => response.json())
      .then((result) => {
        if (result.success) {
          alert("System created successfully!");
          window.location.reload();
        } else {
          alert("Error creating system.");
        }
      })
      .catch((error) => console.error("Error:", error));
  }
});
