const path = require("path");
const DependencyExtractionWebpackPlugin = require("@wordpress/dependency-extraction-webpack-plugin");

module.exports = {
  entry: {
    "title-input": "./src/blocks/title-input/index.js",
    "url-input": "./src/blocks/url-input/index.js",
    "logo-url-input": "./src/blocks/logo-url-input/index.js",
    "order-input": "./src/blocks/order-input/index.js",
    "submit-button": "./src/blocks/submit-button/index.js",
  },
  output: {
    path: path.resolve(__dirname, "build"),
    filename: "[name]/index.js",
  },
  module: {
    rules: [
      {
        test: /\.js$/,
        exclude: /node_modules/,
        use: {
          loader: "babel-loader",
          options: {
            presets: ["@wordpress/babel-preset-default"],
          },
        },
      },
      {
        test: /\.css$/,
        use: ["style-loader", "css-loader"],
      },
    ],
  },
  plugins: [new DependencyExtractionWebpackPlugin()],
};
