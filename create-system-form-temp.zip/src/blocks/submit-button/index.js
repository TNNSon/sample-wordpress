const { registerBlockType } = wp.blocks;

registerBlockType("create-system-form/submit-button", {
  title: "Submit Button",
  icon: "button",
  category: "common",
  edit: () => {
    return (
      <div className="submit-button-block">
        <button type="button" disabled>
          Submit (Editor View)
        </button>
      </div>
    );
  },
  save: () => null, // Server-side rendering
});
