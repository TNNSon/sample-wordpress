const { registerBlockType } = wp.blocks;

registerBlockType("create-system-form/order-input", {
  title: "Order Input 1",
  icon: "edit",
  category: "common",
  attributes: {
    title: { type: "string", default: "" },
  },
  edit: ({ attributes, setAttributes }) => {
    return (
      <div className="order-input-block">
        <label>Title:</label>
        <input
          type="text"
          value={attributes.title}
          onChange={(e) => setAttributes({ title: e.target.value })}
          placeholder="Enter Title"
        />
      </div>
    );
  },
  save: () => null, // Use server-side rendering
});
