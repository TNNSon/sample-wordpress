const { registerBlockType } = wp.blocks;

registerBlockType("create-system-form/url-input", {
  title: "Url Input 1",
  icon: "edit",
  category: "common",
  attributes: {
    title: { type: "string", default: "" },
  },
  edit: ({ attributes, setAttributes }) => {
    return (
      <div className="url-input-block">
        <label>Title:</label>
        <input
          type="text"
          value={attributes.title}
          onChange={(e) => setAttributes({ title: e.target.value })}
          placeholder="Enter Title"
        />
      </div>
    );
  },
  save: () => null, // Use server-side rendering
});
