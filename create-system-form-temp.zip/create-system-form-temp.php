<?php
/*
Plugin Name: Create System Form
Description: A plugin to create a system form with custom blocks.
Version: 1.0.0
Author: Your Name
*/

// Register each input block
// function register_create_system_blocks() {
//     $blocks = ['title-input', 'url-input', 'logo-url-input', 'order-input'];

//     foreach ($blocks as $block) {
//         register_block_type("create-system-form/$block", [
//             'render_callback' => "render_{$block}_block",
//             'attributes' => [
//                 $block => [
//                     'type' => 'string',
//                     'default' => '',
//                 ],
//             ],
//         ]);
//     }
// }
// add_action('init', 'register_create_system_blocks');

// function enqueue_create_system_scripts() {
//   $blocks = ['title-input', 'url-input', 'logo-url-input', 'order-input'];

//   foreach ($blocks as $block) {
//       wp_register_script(
//           "create-system-form-$block-script",
//           plugins_url("build/$block/index.js", __FILE__),
//           ['wp-blocks', 'wp-element', 'wp-editor', 'wp-components'],
//           filemtime(plugin_dir_path(__FILE__) . "build/$block/index.js")
//       );
//   }
// }
// add_action('enqueue_block_editor_assets', 'enqueue_create_system_scripts');
function create_system_form_register_blocks() {
  $blocks = [
      'title-input' => 'render_title_input_block',
      'url-input' => 'render_url_input_block',
      'logo-url-input' => 'render_logo_url_input_block',
      'order-input' => 'render_order_input_block',
      'submit-button' => 'render_submit_button_block', // Add submit-button
  ];

  foreach ($blocks as $block => $callback) {
      wp_register_script(
          "create-system-form-{$block}",
          plugins_url("build/{$block}/index.js", __FILE__),
          array('wp-blocks', 'wp-element', 'wp-editor', 'wp-components'),
          filemtime(plugin_dir_path(__FILE__) . "build/{$block}/index.js")
      );

      register_block_type("create-system-form/{$block}", array(
          'editor_script' => "create-system-form-{$block}",
          'render_callback' => $callback,
      ));
  }
}
add_action('init', 'create_system_form_register_blocks');

function render_submit_button_block() {
  ob_start();
  ?>
  <div class="submit-button-block">
      <button type="submit" class="create-system-submit">Submit</button>
  </div>
  <?php
  return ob_get_clean();
}


// Render functions for each block
function render_title_input_block($attributes) {
  $title = isset($attributes['title']) ? esc_attr($attributes['title']) : '';

  ob_start();
  ?>
  <div class="title-input-block">
      <label for="title-input">Title:</label>
      <input type="text" id="title-input" name="title" value="<?php echo $title; ?>" />
  </div>
  <?php
  return ob_get_clean();
}


function render_url_input_block($attributes) {
  $url = isset($attributes['url']) ? esc_url($attributes['url']) : '';

  ob_start();
  ?>
  <div class="url-input-block">
      <label for="url-input">System URL:</label>
      <input type="url" id="url-input" name="url" value="<?php echo $url; ?>" />
  </div>
  <?php
  return ob_get_clean();
}


function render_logo_url_input_block($attributes) {
    $logo_url = esc_url($attributes['logo_url'] ?? '');
    return "<div class='logo-url-input-block'><label>Logo URL:</label><input type='url' name='logo_url' value='$logo_url' /></div>";
}

function render_order_input_block($attributes) {
    $order = esc_attr($attributes['order'] ?? '');
    return "<div class='order-input-block'><label>Order:</label><input type='number' name='order' value='$order' /></div>";
}

// Register a REST API endpoint to handle form submissions
function create_system_form_rest_api() {
    register_rest_route('create-system/v1', '/submit', [
        'methods' => 'POST',
        'callback' => 'handle_create_system_form_submission',
        'permission_callback' => '__return_true',
    ]);
}
add_action('rest_api_init', 'create_system_form_rest_api');

function handle_create_system_form_submission($request) {
    $params = $request->get_json_params();

    $title = sanitize_text_field($params['title'] ?? '');
    $url = esc_url_raw($params['url'] ?? '');
    $logo_url = esc_url_raw($params['logo_url'] ?? '');
    $order = intval($params['order'] ?? 0);

    $post_id = wp_insert_post([
        'post_type' => 'system',
        'post_title' => $title,
        'post_status' => 'publish',
        'meta_input' => [
            'url' => $url,
            'logo_url' => $logo_url,
            'order' => $order,
        ],
    ]);

    if ($post_id) {
        return new WP_REST_Response(['success' => true, 'id' => $post_id], 200);
    }
    return new WP_REST_Response(['success' => false], 500);
}

function enqueue_frontend_scripts() {
  if (is_page()) {
    error_log('Page Slug: ' . get_post_field('post_name', get_the_ID()));
}

  if (is_page('create-system')) { // Check if it's the Create System page
      wp_enqueue_script(
          'create-system-form-submit',
          plugins_url('js/form-submit.js', __FILE__),
          array(),
          filemtime(plugin_dir_path(__FILE__) . 'js/form-submit.js'),
          true
      );
  }
}
add_action('wp_enqueue_scripts', 'enqueue_frontend_scripts');

function create_system_form_register_template($templates) {
  $templates['page-create-system.php'] = __('Create System Page', 'create-system-form');
  return $templates;
}
add_filter('theme_page_templates', 'create_system_form_register_template');

function create_system_form_load_template($template) {
  if (get_page_template_slug() === 'page-create-system.php') {
      $plugin_template = plugin_dir_path(__FILE__) . 'templates/page-create-system.php';
      if (file_exists($plugin_template)) {
          return $plugin_template;
      }
  }
  return $template;
}
add_filter('template_include', 'create_system_form_load_template');
